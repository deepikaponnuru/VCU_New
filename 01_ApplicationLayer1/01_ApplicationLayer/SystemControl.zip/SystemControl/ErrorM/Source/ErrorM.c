/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Error manager

File Name  : ErrorM.c

Description: This is the Error manager source file.

Version    : 1.0

Date       : 10/12/2025

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "ErrorM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eErrorM_ErrorManagerState ErrorM_ErrorMState_E = eErrorM_Error;
eReadyModeM_ReadyModeMState ErrorM_ReadyModeMStateSysSig_E   = eReadyModeM_Error;
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ErrorM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ErrorM_Init

Description     : This function initializes the internal variables 

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ErrorM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ErrorM_Proc10ms

Description     : This function will be periodically called for 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{	
    ErrorM_ReadyModeMStateSysSig_E = ReadyModeM_GetReadyModeMState();

    if(ErrorM_IsSensorErrorSet(GlobalHeader_ToHighErrorBit_U32,eThrottleSens_1) || ErrorM_IsSensorErrorSet(GlobalHeader_ToHighErrorBit_U32,eThrottleSens_2))
    {
        ErrorM_SetErrorMState(eErrorM_Error);
    }
    else if(ErrorM_ReadyModeMStateSysSig_E == eReadyModeM_Error)
    {
        ErrorM_SetErrorMState(eErrorM_Error);
    }
    else
    {
        ErrorM_SetErrorMState(eErrorM_NoError);
    }

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
static inline boolean ErrorM_IsSensorErrorSet(uint32 errorBits, SensorId_E id)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ErrorM_IsSensorErrorSet

Description     : This function returns True if error is set else return False .

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : boolean

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return (boolean)(((errorBits & (1UL << (uint32)id)) != 0UL) ? TRUE : FALSE);
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ErrorM_SetErrorMState(eErrorM_ErrorManagerState ErrorMState_E)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ErrorM_IsSensorErrorSet

Description     : This function returns True if error is set else return False .

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : boolean

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    ErrorM_ErrorMState_E = ErrorMState_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eErrorM_ErrorManagerState ErrorM_GetErrorManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ErrorM_GetErrorManagerState

Description     : This function returns ErrorManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eErrorM_ErrorManagerState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return ErrorM_ErrorMState_E;
}
	


