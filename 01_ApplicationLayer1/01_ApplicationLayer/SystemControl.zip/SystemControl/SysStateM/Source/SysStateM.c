/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: System state machine.

File Name  : SysStateM.c

Description: This is the SysStateM source file.

Version    : 1.0

Date       : 06/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "SysStateM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* Initialize the global variables */
eSysStateM_SystemState eSysStateM_SystemState_E 		= eSysStateM_WakeUpMode;
eEcuM_EcuMState SysStateM_EcuManagerStateIn_E         	= eEcuM_NoError;
eErrorM_ErrorManagerState SysStateM_ErrorMStatusIn_E  	= eErrorM_NoError;
eReadyModeM_ReadyModeMState SysStateM_ReadyModeMStIn_E  = eReadyModeM_NoError;
eSysStateM_SystemState SysStateM_SystemState_E        	= eSysStateM_WakeUpMode;
eSysStateM_SystemState SysStateM_SystemStatePrev_E    	= eSysStateM_WakeUpMode;
float32 SysStateM_TimeInPreRun_F32 = 0.0F;

/* Hardware dependency values */
uint8 SysStateM_uCSelfTestsState_U8         = SysStateM_PASSED;
uint8 SysStateM_PmicSelfTestState_U8        = SysStateM_PASSED;
uint8 SysStateM_ChargerMgrSysSigIn_U8       = IoHwDio_LOW;
uint8 SysStateM_VehicleLockStateCan_U8      = eCanInp_Locked;
uint8 SysStateM_CalibReqStatusDigIn_U8      = eCalibrationM_Disable;
uint8 SysStateM_IgnitionSwStatusDigIn_U8    = IoHwDio_HIGH;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void SysStateM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : SysStateM_Init

Description     : This function initializes the internal variables.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    SysStateM_SystemState_E     = eSysStateM_WakeUpMode;
    SysStateM_SystemStatePrev_E = eSysStateM_WakeUpMode;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void SysStateM_Proc10ms(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : SysStateM_Proc10ms

Description     : This function will be periodically called for 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

    /* Get error status from Error manager SysStateM_ErrorMStatusIn_E */
    SysStateM_ErrorMStatusIn_E = ErrorM_GetErrorManagerState();

    /* Get Ecu manager state from Ecu manager */
    SysStateM_EcuManagerStateIn_E = EcuM_GetEcuMState();
	
	/* Get ReadyModeManager state from ReadyMode Manager */
    SysStateM_ReadyModeMStIn_E = ReadyModeM_GetReadyModeMState();

    /* Get Charger Manager state from Charger Manager */
    SysStateM_ChargerMgrSysSigIn_U8 = ChargerM_GetChargerManagerState();
    
    /* Get calibration request status from calibration status */
    SysStateM_CalibReqStatusDigIn_U8 = IoHwCalib_GetCalibReqStatus();
    
    /* TO DO : Get Ignition KL15 status from Dio(Yet to implement)  */
    SysStateM_IgnitionSwStatusDigIn_U8 = IoHwDio_Read(eIoHwDio_Kl15_InDIN);

    /* Get VehicleLock status from can GetVehicleLock status */
    SysStateM_VehicleLockStateCan_U8 = CanInp_GetVehicleLockStateReq();

	switch(SysStateM_SystemState_E)
	{
	    case eSysStateM_WakeUpMode:
	        SysStateM_TimeInPreRun_F32 = SysStateM_TimeInPreRun_F32 + SysStateM_SAMPLING_RATE;
	        /* When system state is in WakeUpMode check ErrorManagerState is Error */
	        if((SysStateM_ErrorMStatusIn_E == eErrorM_Error))
	        {
	            /* The system state transit to  ErrorMode */
	            SysStateM_SystemState_E = eSysStateM_ErrorMode;
	        }
	        /* When system state is in WakeUpMode check EcuManagerState is Active */
	        else if(SysStateM_EcuManagerStateIn_E == eEcuM_Active)
	        {
	            /* The system state transit to  CalibrationMode */
	            SysStateM_SystemState_E =  eSysStateM_CalibrationMode;
	        }
			/* When system state is in WakeUpMode check ChargerManagerState is Enabled */
			else if(SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Enable)
			{
				/* The system state transit to  StopReadyMode */
	            SysStateM_SystemState_E = eSysStateM_StopReadyMode;
			}
	        break;
			
	    case eSysStateM_CalibrationMode:
			SysStateM_TimeInPreRun_F32 = SysStateM_TimeInPreRun_F32 + SysStateM_SAMPLING_RATE;
            /* When system state is in CalibrationMode check ErrorManagerState is Error */
	        if((SysStateM_ErrorMStatusIn_E == eErrorM_Error))
	        {
	            /* The system state transit to  ErrorMode */
	            SysStateM_SystemState_E = eSysStateM_ErrorMode;
	        }
			  /* When system state is in CalibrationMode check CalibReqStatus is  Disabled */
            else if(SysStateM_CalibReqStatusDigIn_U8 == eCalibrationM_Disable)
            {
                /* The system state transit to  eSysStateM_StartUpTestMode */
                SysStateM_SystemState_E = eSysStateM_StartUpTestMode;
            }
			/* When system state is in CalibrationMode check ChargerManagerState is Enabled */
			else if(SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Enable)
			{
				/* The system state transit to  StopReadyMode */
	            SysStateM_SystemState_E = eSysStateM_StopReadyMode;
			}
	       break;
		   
	    case eSysStateM_StartUpTestMode:
			SysStateM_TimeInPreRun_F32 = SysStateM_TimeInPreRun_F32 + SysStateM_SAMPLING_RATE;
            /* When system state is in StartUpTestMode check ErrorManagerState is Error */
			if((SysStateM_ErrorMStatusIn_E == eErrorM_Error))
			{
	            /* The system state transit to  ErrorMode */
	            SysStateM_SystemState_E = eSysStateM_ErrorMode;
	        }
	        /* When system state is in StartUpTestMode check all of the following tests are PASSED uCSelfTestStatus and
	           PmicSelfTestStatus and VehicleLockStateCan is Unlocked */
            else if((SysStateM_uCSelfTestsState_U8 == SysStateM_PASSED) &&
                    (SysStateM_PmicSelfTestState_U8 == SysStateM_PASSED) &&
                    (SysStateM_VehicleLockStateCan_U8 == eCanInp_Unlocked))
            {
                /* The system state transit to  StartReadyMode */
                SysStateM_SystemState_E = eSysStateM_StartReadyMode;
            }
			/* When system state is in StartUpTestMode check ChargerManagerState is enabled */
			else if(SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Enable)
			{
				/* The system state transit to StopReadyMode */
	            SysStateM_SystemState_E = eSysStateM_StopReadyMode;
			}
            break;
			
	    case eSysStateM_StartReadyMode:
			SysStateM_TimeInPreRun_F32 = SysStateM_TimeInPreRun_F32 + SysStateM_SAMPLING_RATE;
	        /* When system state is in StartReadyMode check ErrorManagerState is Error */
			if((SysStateM_ErrorMStatusIn_E == eErrorM_Error))
	        {
	            /* The system state transit to  ErrorMode */
	            SysStateM_SystemState_E = eSysStateM_ErrorMode;
	        }
	        /* When system state is in StartReadyMode check ReadyModeMngrState is SystemReady and IgnitionSwStatus is enabled */
	        else if((SysStateM_ReadyModeMStIn_E ==  eReadyModeM_SystemReady) &&
                    (SysStateM_IgnitionSwStatusDigIn_U8 == IoHwDio_HIGH))
	        {
	             /* The system state transit to RunMode */
	             SysStateM_SystemState_E = eSysStateM_RunMode;
	        }
	        /* When system state is in StartReadyMode check IgnitionSwStatus is Disabled and TimeInPreRun is greater than Threshold */
	        else if((SysStateM_IgnitionSwStatusDigIn_U8 == IoHwDio_LOW) &&
					(SysStateM_TimeInPreRun_F32 >= SysStateM_TIMER_THRESHOLD))
	        {
	            /* The system state transit to StopReadyMode */
	            SysStateM_SystemState_E = eSysStateM_StopReadyMode;
	        }
			/* When system state is in StartReadyMode check ChargerManagerState is enabled */
			else if(SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Enable)
			{
				/* The system state transit to StopReadyMode */
	            SysStateM_SystemState_E = eSysStateM_StopReadyMode;
			}
	        break;

        case eSysStateM_RunMode:
	         /* When system state is in RunMode check for errors */
            if((SysStateM_ReadyModeMStIn_E == eErrorM_Error) || (SysStateM_ErrorMStatusIn_E == eErrorM_Error))
            {
                SysStateM_SystemState_E = eSysStateM_ErrorMode;
            }
			/* When system state is in RunMode check IgnitionSwStatus is Disable or
			   ChargerManager is Enable or VehicleLOCKState is Locked */
	        else if((SysStateM_IgnitionSwStatusDigIn_U8 == IoHwDio_LOW ) ||
                (SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Enable) ||
                (SysStateM_VehicleLockStateCan_U8 == eCanInp_Locked))
	        {
                /* The system state transit to StopReadyMode */
                SysStateM_SystemState_E = eSysStateM_StopReadyMode;
	        }
	        break;

        case eSysStateM_StopReadyMode:
                    // SysStateM_TimeInPreRun_F32 re-intializing to 0
                    SysStateM_TimeInPreRun_F32 = 0.0F;
            /* When system state is in StopReadyMode check ReadyModeMngrStateSysSig_U8 is Disable ,
               IgnitionSwStatusDigIn_U8 is Disable and SysStateM_ChargerMgrSysSigIn_U8 is Disable */
            if((SysStateM_ReadyModeMStIn_E == eReadyModeM_SystemDisable ) &&
                (SysStateM_IgnitionSwStatusDigIn_U8 == IoHwDio_LOW) &&
                (SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Disable))
            {
                /* The system state transit to ShutDownMode */
                SysStateM_SystemState_E = eSysStateM_ShutDownMode;
            }
            break;

        case eSysStateM_ErrorMode:
			/* When system state is in ErrorMode check IgnitionSwStatus is Disable or
			   ChargerManager is Enable or VehicleLOCKState is Locked */
            if((SysStateM_IgnitionSwStatusDigIn_U8 == IoHwDio_LOW ) ||
                (SysStateM_ChargerMgrSysSigIn_U8 == eChargerM_Enable) ||
                (SysStateM_VehicleLockStateCan_U8 == eCanInp_Locked))
	        {
                /* The system state transit to StopReadyMode */
                SysStateM_SystemState_E = eSysStateM_StopReadyMode;
	        }
			break;
			
	    case eSysStateM_ShutDownMode:
            /* When system state is in ShutDownMode check EcuManagerState is Finished */
            if(SysStateM_EcuManagerStateIn_E == eEcuM_Finished)
            {
                /* The system state transit to SleepMode */
                SysStateM_SystemState_E = eSysStateM_SleepMode;
            }
            break;
			
	    case eSysStateM_SleepMode:
	        break;
	}

	/* Previous system state */
	SysStateM_SystemStatePrev_E = SysStateM_SystemState_E;
}


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eSysStateM_SystemState SysStateM_GetCurrentState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------
Function Name   : SysStateM_GetCurrentState

Description     : This function returns the current system state

In Parameter    : N/A.

Out Parameter   : N/A.

In-Out Parameter: N/A.

Return          : eSysStateM_SystemState
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
	/* Return current state */
	return SysStateM_SystemState_E;

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eSysStateM_SystemState SysStateM_GetPrevState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------
Function Name   : SysStateM_GetPrevState

Description     : This function returns the previous system state 

In Parameter    : N/A.

Out Parameter   : N/A.

In-Out Parameter: N/A.

Return          : eSysStateM_SystemState
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
	/* Return previous system state */
	return SysStateM_SystemStatePrev_E;
}

