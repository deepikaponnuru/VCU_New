/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: System state machine

File Name  : SysStateM_Ext.c

Description: This is the SysStateM public header.

Version    : 1.0

Date       : 06/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
#ifndef _SYSSTATEM_EXT_H_
#define _SYSSTATEM_EXT_H_

/*------------------------------------------------------------------ Standard Types Include ---------------------------------------------------------------*/
#include "Std_Types.h"
#include "IoHwDio_Ext.h"
#include "DcVolt_Ext.h"
#include "ErrorM_Ext.h"
#include "IoHwCalib_Ext.h"
#include "EcuM_Ext.h"
#include "CanInp_Ext.h"
#include "ReadyModeM_Ext.h"
#include "ChargerM_Ext.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Global Macros -----------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------------------------------------- Global Typedefs -----------------------------------------------------------------*/
typedef enum
{
	eSysStateM_WakeUpMode = 0U,
	eSysStateM_CalibrationMode,
	eSysStateM_StartUpTestMode,
	eSysStateM_StartReadyMode,
	eSysStateM_ErrorMode,
	eSysStateM_RunMode,
	eSysStateM_StopReadyMode,
	eSysStateM_ShutDownMode,
	eSysStateM_SleepMode
}eSysStateM_SystemState;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Global Variables Declaration --------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------- Global Interface Functions Declaration ----------------------------------------------------------*/
void SysStateM_Init(void);
void SysStateM_Proc10ms(void);
eSysStateM_SystemState SysStateM_GetPrevState(void);
eSysStateM_SystemState SysStateM_GetCurrentState(void);
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
#endif /* _SYSSTATEM_EXT_H_ */
