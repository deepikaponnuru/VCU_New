/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: System state machine

File Name  : SysStateM_Int.c

Description: This is the SysStateM private header.

Version    : 1.0

Date       : 06/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

#ifndef _STATEMACHINE_INT_H_
#define _STATEMACHINE_INT_H_

/*----------------------------------------------------------------------- Import Module Include Section ----------------------------------------------------*/
#include "SysStateM_Ext.h"
/*----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------ Global Macros --------------------------------------------------------------------*/
#define SysStateM_FAILED           (0U)
#define SysStateM_PASSED           (1U)
#define SysStateM_UNLOCKED         (0U)
#define SysStateM_LOCKED           (1U)
#define SysStateM_SAMPLING_RATE    (0.01F)
#define SysStateM_TIMER_THRESHOLD  (5.0F)

/*----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------  Enum --------------------------------------------------------------------*/
extern eSysStateM_SystemState eSysStateM_SystemState_E;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------Global variable declaration-------------------------------------------------------------*/

extern eEcuM_EcuMState SysStateM_EcuManagerStateIn_E;
extern eErrorM_ErrorManagerState SysStateM_ErrorMStatusIn_E;
extern eReadyModeM_ReadyModeMState SysStateM_ReadyModeMStIn_E;
extern eSysStateM_SystemState SysStateM_SystemState_E ;
extern eSysStateM_SystemState SysStateM_SystemStatePrev_E;
extern float32 TimeInPreRun;

/*Hardware dependency values*/
extern uint8 SysStateM_uCSelfTestsState_U8;
extern uint8 SysStateM_PmicSelfTestState_U8;
extern uint8 SysStateM_VehicleLockStateCan_U8;
extern uint8 SysStateM_CalibReqStatusDigIn_U8;
extern uint8 SysStateM_IgnitionSwStatusDigIn_U8;
extern uint8 SysStateM_ChargerMgrSysSig_U8;


/*----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------  Internal Function Declaration ----------------------------------------------------------*/

/*----------------------------------------------------------------------------------------------------------------------------------------------------------*/
#endif /* _STATEMACHINE_INT_H_ */
