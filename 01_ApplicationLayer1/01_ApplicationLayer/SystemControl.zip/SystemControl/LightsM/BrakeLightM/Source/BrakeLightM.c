/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: BrakeLight manager

File Name  : BrakeLightM.c

Description: This is the BrakeLight manager source file.

Version    : 1.0

Date       : 08/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "BrakeLightM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eBrakeLightM_BrakeLightManagerState BrakeLightM_BrakePedalMStatusDigIn_E      =  eBrakeLightM_Disable;
float32 BrakeLightM_BrakePedalPressTimer = 0.0F;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void BrakeLightM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BrakeLightM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void BrakeLightM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BrakeLightM_Proc10ms

Description     :

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* TO DO : Get BrakePedal status from Dio(Yet to implement) */
    BrakeLightM_BrakePedalMStatusDigIn_E = IoHwDio_Read(eIoHwDio_Dig5DIN);

    /* When Brake Pedal Status is enabled more than Pedal Threshold */
    if(BrakeLightM_BrakePedalMStatusDigIn_E == eBrakeLightM_Enable)
    {
        BrakeLightM_BrakePedalPressTimer += BrakeLightM_SAMPLINGRATE;
    }
    /* When Brake Pedal Status is Disabled */
    if(BrakeLightM_BrakePedalMStatusDigIn_E == eBrakeLightM_Disable)
    {
        BrakeLightM_BrakePedalPressTimer = 0.0F;
        /* TO DO : BrakeLight = OFF ==> BrakeLightActuatorDigOut = OFF */
        IoHwDio_Write(eIoHwDio_Hs4_DOUT,  0);
    }
    else if(BrakeLightM_BrakePedalPressTimer > BrakeLightM_BRAKE_PRESS_THRESHOLD)
    {
        /* TO DO : BrakeLight = ON ==> BrakeLightActuatorDigOut = ON */
        IoHwDio_Write(eIoHwDio_Hs4_DOUT,  1);
    }
}



/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eBrakeLightM_BrakeLightManagerState BrakeLightM_GetBrakeLightManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BrakeLightM_GetBrakeLightManagerState

Description     : This function returns BrakeLightManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : BrakeLightM_BrakePedalMStatusIn_E

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return BrakeLightM_BrakePedalMStatusDigIn_E;
}



