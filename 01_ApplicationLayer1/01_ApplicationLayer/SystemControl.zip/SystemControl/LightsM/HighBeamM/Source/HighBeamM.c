/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: HighBeam manager

File Name  : HighBeamM.c

Description: This is the HighBeam manager source file.

Version    : 1.0

Date       : 08/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "HighBeamM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHighBeamM_HighBeamManagerState HighBeamM_HighBeamStatusDigIn_E      = eHighBeamM_Disable;
uint8 PassingBeamSwitchStatusDigIn_U8 = 0U;
float32 HighBeamM_PassingBeamPressTimer_F32 = 0.0F;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HighBeamM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HighBeamM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{


}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HighBeamM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HighBeamM_Proc10ms

Description     :

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* TO DO : Get High Beam status from Dio(Yet to implement)  */
    HighBeamM_HighBeamStatusDigIn_E = IoHwDio_Read(eIoHwDio_Dig9DIN);

    /* TO DO : Get Passing Beam status from Dio(Yet to implement)  */
    PassingBeamSwitchStatusDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig10DIN);

    if(PassingBeamSwitchStatusDigIn_U8 == HighBeamM_PRESSED)
    {
        HighBeamM_PassingBeamPressTimer_F32 += HighBeamM_SAMPLINGRATE;
    }
    else if(PassingBeamSwitchStatusDigIn_U8 == HighBeamM_PRESSED)
    {
        HighBeamM_PassingBeamPressTimer_F32 = 0.0;
    }
    /* When HighBeamStatusDigIn_E is Enabled or PassingBeamSwitch is pressed more than Threshold */
    if((HighBeamM_HighBeamStatusDigIn_E == eHighBeamM_Enable) || (HighBeamM_PassingBeamPressTimer_F32 > HighBeamM_HIGHBEAM_PRESS_THRESHOLD))
    {
        /* TO DO : High Beam = ON ==> HighBeamActuatorDigOut = On*/
        IoHwDio_Write(eIoHwDio_Hs1_DOUT,  1);

    }
    /* When HighBeamStatusDigIn_E is Disabled and PassingBeamSwitch is Not pressed */
    else if((HighBeamM_HighBeamStatusDigIn_E == eHighBeamM_Disable) && (PassingBeamSwitchStatusDigIn_U8 == HighBeamM_NOT_PRESSED))
    {
        /* TO DO : High Beam = OFF ==> HighBeamActuatorDigOut = OFF*/
        IoHwDio_Write(eIoHwDio_Hs1_DOUT,  0);
    }

    /*   DRLActuatorDigOut = ON */
    IoHwDio_Write(eIoHwDio_Hs7_DOUT,  1);


}



/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHighBeamM_HighBeamManagerState HighBeamM_GetHighBeamManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HighBeamM_GetHighBeamManagerState

Description     : This function returns HighBeamManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : HighBeamM_HighBeamMState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return HighBeamM_HighBeamStatusDigIn_E;
}



