/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: ReverseLight manager

File Name  : ReverseLightM.c

Description: This is the ReverseLight manager source file.

Version    : 1.0

Date       : 08/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "ReverseLightM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eReverseLightM_ReverseLightManagerState ReverseLightM_ReverseLightMState_E      = eReverseLightM_Enable;
eDriveM_DriveManagerState DriveM_PresentDriveMode_E          = eDriveM_Neutral;
uint8 ReverseLightM_VehicleLockStatusDig_U8                  = ReverseLightM_LOCKED;
uint8 ReverseLightM_BrakePedalStatusDigIn_U8                 = eReverseLightM_Disable;
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ReverseLightM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ReverseLightM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ReverseLightM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ReverseLightM_Proc10ms

Description     :

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* Get Present Drive Mode from DriveM_GetDriveManagerState */
    DriveM_PresentDriveMode_E = DriveM_GetDriveManagerState();

    /* TO DO : Get Brake Pedal status from Dio(Yet to implement)  */
    ReverseLightM_BrakePedalStatusDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig5DIN);

    /* TO DO : Get Vehicle Lock status from Dio(Yet to implement)  */
    ReverseLightM_VehicleLockStatusDig_U8 = IoHwDio_Read(eIoHwDio_Dig2DIN);

    /* When Present Drive Mode is Reverse Mode and Brake Pedal is Enabled and Vehicle Lock is Unlocked */
    if((DriveM_PresentDriveMode_E == eDriveM_Reverse) && (ReverseLightM_BrakePedalStatusDigIn_U8 == eReverseLightM_Enable) && (ReverseLightM_VehicleLockStatusDig_U8 == ReverseLightM_UNLOCKED))
    {
        /* TO DO : ReverseLight = ON ==> ReverseLightActuatorDigOut = ON */
        IoHwDio_Write(eIoHwDio_Hs5_DOUT,  1);
    }
    /* When Present Drive Mode is not in Reverse Mode and Brake Pedal is Disabled and Vehicle Lock is Locked */
    else if((DriveM_PresentDriveMode_E != eDriveM_Reverse) && (ReverseLightM_BrakePedalStatusDigIn_U8 == eReverseLightM_Disable) && ( ReverseLightM_VehicleLockStatusDig_U8 == ReverseLightM_LOCKED))
    {
        /* TO DO : ReverseLight = OFF ==> ReverseLightActuatorDigOut = OFF */
        IoHwDio_Write(eIoHwDio_Hs5_DOUT,  0);
    }

}



/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eReverseLightM_ReverseLightManagerState ReverseLightM_GetReverseLightManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ReverseLightM_GetReverseLightManagerState

Description     : This function returns ReverseLightManager State

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : ReverseLightM_ReverseLightMState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return ReverseLightM_ReverseLightMState_E;
}



