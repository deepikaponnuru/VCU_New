/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: HeadLightDrl manager

File Name  : HeadLightDrlM.c

Description: This is the HeadLightDrl manager source file.

Version    : 1.0

Date       : 08/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "HeadLightDrlM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHeadLightDrlM_HeadLightDrlManagerState HeadLightDrlM_HeadLightStatusDig_In_E      = eHeadLightDrlM_Disable;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HeadLightDrlM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HeadLightDrlM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HeadLightDrlM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HeadLightDrlM_Proc10ms

Description     :

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* TO DO : Get HeadLight status from Dio(Yet to implement)  */
    HeadLightDrlM_HeadLightStatusDig_In_E = IoHwDio_Read(eIoHwDio_Dig9DIN);
    /* When HeadLightStatus is Enabled */
    if((HeadLightDrlM_HeadLightStatusDig_In_E == eHeadLightDrlM_Enable) )
    {
        /* TO DO: HeadLightActuatorDigOut = ON
         *        DRLActuatorDigOut = OFF
         */
    }
    /* When HeadLightStatus is Disabled */
    else if((HeadLightDrlM_HeadLightStatusDig_In_E == eHeadLightDrlM_Disable) )
    {
        /* TO DO: HeadLightActuatorDigOut = OFF
         *        DRLActuatorDigOut = ON
         */
     }


}



/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHeadLightDrlM_HeadLightDrlManagerState HeadLightDrlM_GetHeadLightDrlManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HeadLightDrlM_GetHeadLightDrlManagerState

Description     : This function returns HeadLightDrlManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : HeadLightDrlM_HeadLightStatusDig_In_E

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return HeadLightDrlM_HeadLightStatusDig_In_E;
}



