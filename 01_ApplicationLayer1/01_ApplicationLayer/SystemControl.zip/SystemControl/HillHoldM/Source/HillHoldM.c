/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: HillHoldM

File Name  : HillHoldM.c

Description: This is the HillHold manager source file.

Version    : 1.0

Date       : 05/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "HillHoldM_Int.h"

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHillHoldM_HillHoldMState ReadyM_HillHoldMState_E     = eHillHoldM_Disable;
eCanInp_CanState HillHoldM_HillHoldReqCan_E  = eCanInp_Disable;
uint8 HillHoldM_HillHoldReqDigIn_U8 = 0U;
float32 HillHoldM_McuSpeed_F32 = 0.0F;




/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HillHoldM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HillHoldM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{


}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HillHoldM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HillHoldM_Proc10ms

Description     : This function will be periodically called for 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* TO DO : Get HillHoldReq status from Dio(Yet to implement)  */
    HillHoldM_HillHoldReqDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig12DIN);

    /* Get HillHoldReq through CAN from CanInp_GetHillHoldReq */
    HillHoldM_HillHoldReqCan_E = CanInp_GetHillHoldReq();

    /* When Either HillHoldReqCan is Enabled or HillHoldReqDig is Enabled and Mcu Speed is Less than Speed Threshold */
    if(((HillHoldM_HillHoldReqCan_E == eCanInp_Enable) | (HillHoldM_HillHoldReqDigIn_U8 == eHillHoldM_Enable)) &&
            (HillHoldM_McuSpeed_F32 < HillHoldM_MCU_SPEED_THRESHOLD))
    {
        /* The HillHold State transit to Enable */
        ReadyM_HillHoldMState_E = eHillHoldM_Enable;
    }
    else
    {
        /* The HillHold State transit to Disable */
        ReadyM_HillHoldMState_E = eHillHoldM_Disable;
    }


}


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHillHoldM_HillHoldMState HillHoldM_GetManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HillHoldM_GetManagerState

Description     : This function returns HillHoldManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : ReadyM_HillHoldMState_E

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return ReadyM_HillHoldMState_E;
}
