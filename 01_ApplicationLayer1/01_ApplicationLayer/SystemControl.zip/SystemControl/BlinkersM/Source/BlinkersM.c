/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Blinkers manager

File Name  : BlinkersM.c

Description: This is the Blinkers manager source file.

Version    : 1.0

Date       : 07/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "BlinkersM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eBlinkersM_BlinkersManagerState BlinkersM_BlinkersMState_E = eBlinkersM_BlinkersOff;
eBlinkersM_BlinkersManagerState BlinkersM_BlinkerRightSwitchStDigIn = IoHwDio_LOW;
eBlinkersM_BlinkersManagerState BlinkersM_BlinkerLeftSwitchStDigIn = IoHwDio_LOW;
uint8 BlinkersM_BlinkerRightSwTimer = 0U;
uint8 BlinkersM_BlinkerLeftSwTimer = 0U;
uint16 BlinkersM_BlinkCounter = 0U;
uint8  BlinkersM_BlinkState   = 0U;
uint8  BlinkersM_LeftToggleCount  = 0U;
uint8  BlinkersM_RightToggleCount  = 0U;
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void BlinkersM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BlinkersM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    BlinkersM_BlinkersMState_E = eBlinkersM_BlinkersOff;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void BlinkersM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BlinkersM_Proc10ms

Description     : This function is called for every 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void
BlinkersM_LOWER_THRESHOLD
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* TO DO : Get BlinkerRight status from Dio(Yet to implement)  */
    BlinkersM_BlinkerRightSwitchStDigIn = IoHwDio_Read(eIoHwDio_Dig8DIN);

    /* TO DO : Get BlinkerLeftSwitch status from Dio(Yet to implement)  */
    BlinkersM_BlinkerLeftSwitchStDigIn = IoHwDio_Read(eIoHwDio_Dig7DIN);

    /* When the Blinker Right Switch is pressed Increment the BlinkerRightSwTimer */
    if(BlinkersM_BlinkerRightSwitchStDigIn == IoHwDio_HIGH)
    {
        BlinkersM_BlinkerRightSwTimer += BlinkersM_SAMPLING_RATE;
    }
    /* When Blinker Right Switch is released, Initialize BlinkerRightSwTimer to 0 */
    else if(BlinkersM_BlinkerRightSwitchStDigIn == IoHwDio_LOW)
    {
        BlinkersM_BlinkerRightSwTimer = 0U;
    }
    /* When the Blinker Left Switch is pressed Increment the BlinkerLeftSwTimer */
    if(BlinkersM_BlinkerLeftSwitchStDigIn == IoHwDio_HIGH)
    {
        BlinkersM_BlinkerLeftSwTimer += BlinkersM_SAMPLING_RATE;
    }
    /* When Blinker Left Switch is released, Initialize BlinkerLeftSwTimer to 0 */
    else if(BlinkersM_BlinkerLeftSwitchStDigIn == IoHwDio_LOW)
    {
        BlinkersM_BlinkerLeftSwTimer = 0U;
    }

    switch(BlinkersM_BlinkersMState_E)
    {
        case eBlinkersM_BlinkersOff :
        {
            BlinkersM_BlinkCounter = 0u;
            BlinkersM_BlinkState   = 0u;

            IoHwDio_Write(eIoHwDio_Hs6_DOUT, 0u);
            IoHwDio_Write(eIoHwDio_Hs7_DOUT, 0u);

            /* When Right Blinker is Pressed in between the range of lower and upper threshold */
            if((BlinkersM_BlinkerRightSwTimer <  BlinkersM_UPPER_THRESHOLD) && (BlinkersM_BlinkerRightSwTimer > BlinkersM_LOWER_THRESHOLD))
            {
                BlinkersM_BlinkersMState_E = eBlinkersM_RightBlinkerOnTwice;
            }
            /* When Left Blinker is Pressed in between the range of lower and upper threshold */
            else if((BlinkersM_BlinkerLeftSwTimer <  BlinkersM_UPPER_THRESHOLD) && (BlinkersM_BlinkerLeftSwTimer > BlinkersM_LOWER_THRESHOLD))
            {
                BlinkersM_BlinkersMState_E = eBlinkersM_LeftBlinkerOnTwice;
            }
            /* When Right Blinker is Pressed more than Upper threshold */
            else if(BlinkersM_BlinkerRightSwTimer >=  BlinkersM_UPPER_THRESHOLD)
            {
                BlinkersM_BlinkersMState_E = eBlinkersM_RightBlinkerOnContinuous;
            }
            /* When Left Blinker is pressed more than Upper threshold */
            else if(BlinkersM_BlinkerLeftSwTimer >=  BlinkersM_UPPER_THRESHOLD)
            {
                BlinkersM_BlinkersMState_E = eBlinkersM_LeftBlinkerOnContinuous;
            }
            break;
         }
        case eBlinkersM_RightBlinkerOnTwice:
        {
            /* TO DO : RightBlinkersOnTwice and transit to off*/
            if( BlinkersM_RightToggleCount < 4u)
            {
               BlinkersM_BlinkCounter++;
               if(BlinkersM_BlinkCounter >= BlinkersM_FREQ_3_2HZ)
               {
                   BlinkersM_BlinkCounter -= BlinkersM_FREQ_3_2HZ;
                   BlinkersM_BlinkState ^= 1u;
                   BlinkersM_RightToggleCount++;        /* Count toggles */
               }
               IoHwDio_Write(eIoHwDio_Hs8_DOUT, BlinkersM_BlinkState);
            }
            else
            {
                BlinkersM_BlinkersMState_E = eBlinkersM_BlinkersOff;
                BlinkersM_RightToggleCount = 0;
            }
            break;
        }
        case eBlinkersM_LeftBlinkerOnTwice:
        {
            /* TO DO : LeftBlinkersOnTwice and transit to off*/
            if( BlinkersM_LeftToggleCount < 4u)
            {
               BlinkersM_BlinkCounter++;
               if(BlinkersM_BlinkCounter >= BlinkersM_FREQ_3_2HZ)
               {
                   BlinkersM_BlinkCounter -= BlinkersM_FREQ_3_2HZ;
                   BlinkersM_BlinkState ^= 1u;
                   BlinkersM_LeftToggleCount++;        /* Count toggles */
               }
               IoHwDio_Write(eIoHwDio_Hs6_DOUT, BlinkersM_BlinkState);
            }
            else
            {
                BlinkersM_BlinkersMState_E = eBlinkersM_BlinkersOff;
                BlinkersM_LeftToggleCount = 0;
            }
            break;
        }
        case eBlinkersM_RightBlinkerOnContinuous:
        {
            BlinkersM_BlinkCounter++;

            if(BlinkersM_BlinkCounter >= BlinkersM_FREQ_3_2HZ)
            {
                BlinkersM_BlinkCounter -= BlinkersM_FREQ_3_2HZ;
                BlinkersM_BlinkState ^= 1u;
            }

            IoHwDio_Write(eIoHwDio_Hs8_DOUT, BlinkersM_BlinkState);

            /* When BlinkerRightSwTimer or BlinkerLeftSwTimer is greater than Lower Threshold */
            if((BlinkersM_BlinkerRightSwTimer > BlinkersM_LOWER_THRESHOLD) || (BlinkersM_BlinkerLeftSwTimer >  BlinkersM_LOWER_THRESHOLD))
            {
                /* RightBlinkersOnTwice and transit to BlinkersOff */
                BlinkersM_BlinkersMState_E = eBlinkersM_BlinkersOff;
            }
            /* When BlinkerLeftSwTimer is greater than Upper Threshold */
            else if(BlinkersM_BlinkerLeftSwTimer >=  BlinkersM_UPPER_THRESHOLD)
            {
                /* Blinkers state transit to LeftBlinkerOnContinuous */
                BlinkersM_BlinkersMState_E = eBlinkersM_LeftBlinkerOnContinuous;
            }

            break;
        }
        case eBlinkersM_LeftBlinkerOnContinuous:
        {
            BlinkersM_BlinkCounter++;

            if(BlinkersM_BlinkCounter >= BlinkersM_FREQ_3_2HZ)
            {
                BlinkersM_BlinkCounter -= BlinkersM_FREQ_3_2HZ;
                BlinkersM_BlinkState ^= 1u;
            }

            IoHwDio_Write(eIoHwDio_Hs6_DOUT, BlinkersM_BlinkState);

            /* When BlinkerRightSwTimer or BlinkerLeftSwTimer is greater than Lower Threshold */
            if((BlinkersM_BlinkerRightSwTimer > BlinkersM_LOWER_THRESHOLD) || (BlinkersM_BlinkerLeftSwTimer >  BlinkersM_LOWER_THRESHOLD))
            {
                /* RightBlinkers state transit to BlinkersOff */
                BlinkersM_BlinkersMState_E = eBlinkersM_BlinkersOff;
            }
            /* When BlinkerRightSwTimer is greater than Upper Threshold */
            else if(BlinkersM_BlinkerRightSwTimer >=  BlinkersM_UPPER_THRESHOLD)
            {
                /* Blinkers state transit to RightBlinkerOnContinuous */
                BlinkersM_BlinkersMState_E = eBlinkersM_RightBlinkerOnContinuous;
            }
            break;
        }

    }

}


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void BlinkersM_SetBlinkersMState(eBlinkersM_BlinkersManagerState BlinkersMState_E)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BlinkersM_IsSensorErrorSet

Description     : This function returns True if error is set else return False .

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : boolean

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    BlinkersM_BlinkersMState_E = BlinkersMState_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eBlinkersM_BlinkersManagerState BlinkersM_GetBlinkersManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : BlinkersM_GetBlinkersManagerState

Description     : This function returns BlinkersManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eBlinkersM_BlinkersManagerState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return BlinkersM_BlinkersMState_E;
}



