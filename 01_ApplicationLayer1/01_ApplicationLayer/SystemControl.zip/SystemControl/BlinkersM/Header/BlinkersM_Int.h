/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Blinkers manager Internal file

File Name  : BlinkersM_Int.h

Description: This is the  private header.

Version    : 1.0

Date       : 07/01/2026

----------------------------------------------------------------------------------------------------------------------------------------------------------------*/

#ifndef _BLINKERSM_INT_H_
#define _BLINKERSM_INT_H_

/*------------------------------------------------------------- Import Module Include Section ------------------------------------------------------------------*/
#include "BlinkersM_Ext.h"

/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Global Macros ----------------------------------------------------------------------------------*/
#define BlinkersM_ENABLE           (0U)
#define BlinkersM_DISABLE          (1U)
#define BlinkersM_LOWER_THRESHOLD  (150U)
#define BlinkersM_UPPER_THRESHOLD  (500U)
#define BlinkersM_SAMPLING_RATE    (10U)
#define BlinkersM_FREQ_3_2HZ       (16U)
#define BlinkersM_FREQ_1_67HZ      (30U)
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Local Typedefs ---------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* ------------------------------------------------------------ Global Definitions -----------------------------------------------------------------------------*/

extern eBlinkersM_BlinkersManagerState BlinkersM_BlinkersMState_E;
extern eBlinkersM_BlinkersManagerState BlinkersM_BlinkerRightSwitchStDigIn;
extern eBlinkersM_BlinkersManagerState BlinkersM_BlinkerLeftSwitchStDigIn;
extern uint8 BlinkersM_BlinkerRightSwTimer;
extern uint8 BlinkersM_BlinkerLeftSwTimer;
extern uint16 BlinkersM_BlinkCounter;
extern uint8  BlinkersM_BlinkState;
extern uint8  BlinkersM_LeftToggleCount;
extern uint8  BlinkersM_RightToggleCount;
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Static Function Declarations -------------------------------------------------------------------*/
void BlinkersM_SetBlinkersMState(eBlinkersM_BlinkersManagerState BlinkersMState_E);
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

#endif    /* _BLINKERSM_INT_H_ */




