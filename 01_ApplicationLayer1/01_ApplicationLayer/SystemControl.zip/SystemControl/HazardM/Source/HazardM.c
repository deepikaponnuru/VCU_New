/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: HazardM manager

File Name  : HazardM.c

Description: This is the HazardM manager source file.

Version    : 1.0

Date       : 08/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "HazardM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHazardM_HazardManagerState HazardM_HazardMStatusDigIn_E = HazardM_DISABLE;
uint16 HazardM_BlinkCounter = 0u;
uint8  HazardM_BlinkState   = 0u;
uint8 HazardM_HazardMode = HazardM_DISABLE;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HazardM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HazardM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HazardM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HazardM_Proc10ms

Description     :

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* TO DO : Get Hazard Button status from Dio(Yet to implement) */
    HazardM_HazardMStatusDigIn_E = IoHwDio_Read(eIoHwDio_Dig6DIN);
//    HazardM_HazardMStatusDigIn_E = IoHwDio_Read(eIoHwDio_Kl15_InDIN);
//    if(HazardM_HazardMStatusDigIn_E == HazardM_ENABLE)
//        {
//        IoHwDio_Write(eIoHwDio_Hs5_DOUT,  0);
//        IoHwDio_Write(eIoHwDio_Hs2_DOUT,  0);
//        IoHwDio_Write(eIoHwDio_Hs8_DOUT,  1);
//        IoHwDio_Write(eIoHwDio_Hs11_DOUT, 1);
//        IoHwDio_Write(eIoHwDio_Hs5_DOUT,  0);
//                IoHwDio_Write(eIoHwDio_Hs1_DOUT,  1);
//                IoHwDio_Write(eIoHwDio_Hs4_DOUT,  1);
//                IoHwDio_Write(eIoHwDio_Hs10_DOUT,  1);
//                IoHwDio_Write(eIoHwDio_Hs7_DOUT,  1);
//                        IoHwDio_Write(eIoHwDio_Hs3_DOUT,  1);
//                        IoHwDio_Write(eIoHwDio_Hs6_DOUT,  1);
//                        IoHwDio_Write(eIoHwDio_Hs9_DOUT,  1);
//                        IoHwDio_Write(eIoHwDio_Hs12_DOUT,  1);
//                        IoHwDio_Write(eIoHwDio_Hs1_DOUT,  1);
//                                        IoHwDio_Write(eIoHwDio_Hs13_DOUT,  0);
//                                        IoHwDio_Write(eIoHwDio_Hs14_DOUT,  0);
//                                        IoHwDio_Write(eIoHwDio_Hs16_DOUT,  1);
//                                                IoHwDio_Write(eIoHwDio_Hs17_DOUT,  1);
//                                                IoHwDio_Write(eIoHwDio_Hs18_DOUT,  1);
//                                                IoHwDio_Write(eIoHwDio_Hs19_DOUT,  1);
//        }

    /* When Hazard Button Status is Enabled */
    if(HazardM_HazardMStatusDigIn_E == HazardM_ENABLE)
    {
        HazardM_HazardMode = HazardM_ENABLE;
        HazardM_BlinkCounter++;

        if(HazardM_BlinkCounter >= HazardM_FREQ_1_67HZ)
        {
            HazardM_BlinkCounter -= HazardM_FREQ_1_67HZ;
            HazardM_BlinkState ^= 1u;
        }
        /* TO DO : Left and right blinker On for Continuous with 1.5Hz Frequency */
        IoHwDio_Write(eIoHwDio_Hs6_DOUT,  HazardM_BlinkState);
        IoHwDio_Write(eIoHwDio_Hs8_DOUT,  HazardM_BlinkState);

    }
    /* When Hazard Button Status is Disabled */
    else if((HazardM_HazardMStatusDigIn_E == HazardM_DISABLE) && (HazardM_HazardMode == HazardM_ENABLE))
    {
        HazardM_BlinkCounter = 0u;
        HazardM_BlinkState   = 0u;
        IoHwDio_Write(eIoHwDio_Hs6_DOUT,  HazardM_BlinkState);
        IoHwDio_Write(eIoHwDio_Hs8_DOUT,  HazardM_BlinkState);
        HazardM_HazardMode = HazardM_DISABLE;
    }

}


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void HazardM_SetHazardMState(eHazardM_HazardManagerState HazardMState_E)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HazardM_IsSensorErrorSet

Description     : This function returns True if error is set else return False .

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : boolean

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    HazardM_HazardMStatusDigIn_E = HazardMState_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eHazardM_HazardManagerState HazardM_GetHazardManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : HazardM_GetHazardManagerState

Description     : This function returns HazardManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eHazardM_HazardManagerState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return HazardM_HazardMStatusDigIn_E;
}



