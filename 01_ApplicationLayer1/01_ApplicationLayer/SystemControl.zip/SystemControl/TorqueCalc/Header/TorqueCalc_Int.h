/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: TorqueCalc manager Internal file

File Name  : TorqueCalcM_Int.h

Description: This is the  private header.

Version    : 1.0

Date       : 07/01/2026

----------------------------------------------------------------------------------------------------------------------------------------------------------------*/

#ifndef _TorqueCalcM_INT_H_
#define _TorqueCalcM_INT_H_

/*------------------------------------------------------------- Import Module Include Section ------------------------------------------------------------------*/
#include "TorqueCalc_Ext.h"
#include "SysStateM_Ext.h"
#include "IoHwDio_Ext.h"
#include "DriveM_Ext.h"
#include "ThrottleSensor_Ext.h"
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Global Macros ----------------------------------------------------------------------------------*/
#define TorqueCalcM_ENABLE           (0U)
#define TorqueCalcM_DISABLE          (1U)
#define TorqueCalcM_BrakingFactor    (2U)
#define TorqueCalcM_THROTTLE_SIZE 6
#define TorqueCalcM_SPEED_SIZE    6
#define TorqueCalcM_MODE_SIZE     3   // Eco, Normal, Sport


/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Local Typedefs ---------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* ------------------------------------------------------------ Global Definitions -----------------------------------------------------------------------------*/

extern eTorqueCalcM_TorqueCalc TorqueCalcM_TorqueCalcMState_E;
extern eTorqueCalcM_TorqueCalc TorqueCalcM_BlinkerRightSwitchStDigIn;
extern eTorqueCalcM_TorqueCalc TorqueCalcM_BlinkerLeftSwitchStDigIn;
extern uint8 TorqueCalcM_BlinkerRightSwTimer;
extern uint8 TorqueCalcM_BlinkerLeftSwTimer;

/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Static Function Declarations -------------------------------------------------------------------*/
void TorqueCalcM_SetTorqueCalcMState(eTorqueCalcM_TorqueCalc TorqueCalcMState_E);
float32 TorqueCalcM_GetTargetTorque(float32 throttle, float32 speed, eDriveM_DriveManagerState mode);

/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

#endif    /* _TorqueCalcM_INT_H_ */




