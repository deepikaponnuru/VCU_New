/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: TorqueCalc manager

File Name  : TorqueCalcM.c

Description: This is the TorqueCalc manager source file.

Version    : 1.0

Date       : 07/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "TorqueCalc_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eTorqueCalcM_TorqueCalc TorqueCalcM_TorqueCalcMState_E = eTorqueCalcM_TorqueCalcOff;
eSysStateM_SystemState TorqueCalcM_SystemStateSysSig_E         = eSysStateM_WakeUpMode;
float32 TorqueCalcM_AvgThrottlePercent_F32               = 0.0F;
uint8 TorqueCalcM_BrakePedalSwitchStDigIn_U8             = IoHwDio_LOW;
eDriveM_DriveManagerState TorqueCalcM_DriveMState_E      = eDriveM_Neutral;
float32 TorqueCalcM_McuSpeedCan_F32                      = 0.0F;
uint8 TorqueCalcM_EmergencySwitchStDigIn_U8              = IoHwDio_LOW;
uint8 TorqueCalcM_SideStandStDigIn_U8                    = IoHwDio_LOW;
float32 TorqueCalcM_TargetTorque                         = 0.0F;

const float32 ThrottleAxis[TorqueCalcM_THROTTLE_SIZE] = {0.0, 20.0, 40.0, 60.0, 80.0, 100.0};
const float32 SpeedAxis[TorqueCalcM_SPEED_SIZE]       = {0.0, 2000.0, 4000.0, 6000.0, 8000.0, 10000.0};
const float32 TorqueLUT[TorqueCalcM_MODE_SIZE][TorqueCalcM_THROTTLE_SIZE][TorqueCalcM_SPEED_SIZE] = {
    // Eco mode
    {
        {0.0,  10.0,  20.0,  1.0,  10.0,   5.0},   // Throttle = 0%
        {0.0,  30.0,  40.0,  3.0,  20.0,  10.0},   // Throttle = 20%
        {0.0,  50.0,  60.0,  5.0,  30.0,  15.0},   // Throttle = 40%
        {0.0,  70.0,  80.0,  7.0,  40.0,  20.0},   // Throttle = 60%
        {0.0,  90.0, 100.0,  9.0,  50.0,  25.0},   // Throttle = 80%
        {0.0, 110.0, 120.0, 11.0,  60.0,  30.0}    // Throttle = 100%
    },
    // Normal mode
    {
        {0.0,  20.0,  40.0,  30.0,  20.0,  1.0},
        {0.0,  50.0,  70.0,  60.0,  40.0,  2.0},
        {0.0,  80.0, 100.0,  90.0,  60.0,  3.0},
        {0.0, 110.0, 130.0, 120.0,  80.0,  4.0},
        {0.0, 140.0, 160.0, 150.0, 100.0,  5.0},
        {0.0, 170.0, 190.0, 180.0, 120.0,  60.0}
    },
    // Sport mode
    {
        {0.0,  30.0,  60.0,  4.0,  30.0,  15.0},
        {0.0,  70.0, 100.0,  90.0,  60.0,  3.0},
        {0.0, 120.0, 150.0, 13.0,  90.0,  45.0},
        {0.0, 170.0, 200.0, 180.0, 120.0,  6.0},
        {0.0, 220.0, 250.0, 230.0, 150.0,  75.0},
        {0.0, 270.0, 300.0, 280.0, 180.0,  90.0}
    }
};


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void TorqueCalcM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : TorqueCalcM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    TorqueCalcM_TorqueCalcMState_E = eTorqueCalcM_TorqueCalcOff;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void TorqueCalcM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : TorqueCalcM_Proc10ms

Description     : This function is called for every 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void
TorqueCalcM_LOWER_THRESHOLD
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    TorqueCalcM_SystemStateSysSig_E = SysStateM_GetCurrentState();

    TorqueCalcM_AvgThrottlePercent_F32 = ThrottleSens_GetVAvgPercentThrottleSens1_2(eIoHwAna_Ths1Mon,eIoHwAna_Ths2Mon);

    TorqueCalcM_BrakePedalSwitchStDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig5DIN);

    TorqueCalcM_DriveMState_E = DriveM_GetDriveManagerState();

    TorqueCalcM_McuSpeedCan_F32 = CanInp_GetMcuSpeed();

    TorqueCalcM_EmergencySwitchStDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig15DIN);

    TorqueCalcM_SideStandStDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig14DIN);

    if((TorqueCalcM_EmergencySwitchStDigIn_U8 == IoHwDio_HIGH) || (TorqueCalcM_SideStandStDigIn_U8 == IoHwDio_HIGH))
    {
        TorqueCalcM_TargetTorque = 0.0F;
    }
    else
    {
        TorqueCalcM_TargetTorque = TorqueCalcM_GetTargetTorque(TorqueCalcM_AvgThrottlePercent_F32,TorqueCalcM_McuSpeedCan_F32,TorqueCalcM_DriveMState_E);
    }
    if(TorqueCalcM_SystemStateSysSig_E != eSysStateM_RunMode )
    {
        TorqueCalcM_TargetTorque = 0.0F;
    }
    else if(((TorqueCalcM_DriveMState_E == eDriveM_Drive_Normal) || (TorqueCalcM_DriveMState_E == eDriveM_Drive_Eco) || (TorqueCalcM_DriveMState_E == eDriveM_Drive_Sport)) &&
            (TorqueCalcM_BrakePedalSwitchStDigIn_U8 == IoHwDio_HIGH) &&
            (TorqueCalcM_AvgThrottlePercent_F32 == 0) &&
            (TorqueCalcM_TargetTorque < 0))
    {
        TorqueCalcM_TargetTorque = TorqueCalcM_TargetTorque * TorqueCalcM_BrakingFactor;
    }

    // TO DO : TorqueCalcM_TargetTorque to be sent on CAN


}

float32 TorqueCalcM_GetTargetTorque(float32 throttle, float32 speed, eDriveM_DriveManagerState mode)
{
    if (mode < 0) mode = 0;
    if (mode >= TorqueCalcM_MODE_SIZE) mode = TorqueCalcM_MODE_SIZE - 1;

    // Step 1: For each speed breakpoint, interpolate torque vs throttle
    float32 torqueAtSpeed[TorqueCalcM_SPEED_SIZE];
    for (uint8 j = 0; j < TorqueCalcM_SPEED_SIZE; j++)
    {
        torqueAtSpeed[j] = LookUpTable_GetLookUpTableValue(ThrottleAxis,TorqueLUT[mode][0] + j,TorqueCalcM_THROTTLE_SIZE,throttle);
    }

    // Step 2: Interpolate torque vs speed using the results
    float32 targetTorque = LookUpTable_GetLookUpTableValue(SpeedAxis,torqueAtSpeed,TorqueCalcM_SPEED_SIZE,speed);

    return targetTorque;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void TorqueCalcM_SetTorqueCalcMState(eTorqueCalcM_TorqueCalc TorqueCalcMState_E)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : TorqueCalcM_IsSensorErrorSet

Description     : This function returns True if error is set else return False .

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : boolean

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    TorqueCalcM_TorqueCalcMState_E = TorqueCalcMState_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
float32 TorqueCalcM_GetTargetTorqueCalc(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : TorqueCalcM_GetTorqueCalcManagerState

Description     : This function returns TorqueCalcManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eTorqueCalc

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return TorqueCalcM_TargetTorque;
}



