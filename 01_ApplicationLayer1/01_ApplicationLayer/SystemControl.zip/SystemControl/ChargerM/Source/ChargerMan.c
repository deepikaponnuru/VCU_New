/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Charger manager

File Name  : ChargerM.c

Description: This is the Charger manager source file.

Version    : 1.1

Date       : 19/02/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "ChargerM_Int.h"
#ifndef MAX
#define MAX(a,b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b) (((a) < (b)) ? (a) : (b))
#endif

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------- Global Variables -------------------------------------------------------------------------------*/

eChargerM_ChargerManagerState ChargerM_ChargerMStateSysSig_E = eChargerM_Disable;
eSysStateM_SystemState ChargerM_SystemStateSysSig_E = eSysStateM_WakeUpMode;
eCanInp_CanState ChargerM_ChargerConnectCan_U8 = eCanInp_Disable;
uint8 ChargerM_ChargerConnectDigIn_U8 = IoHwDio_LOW;

uint8 ChargerM_ChargerLock = ChargerM_UNLOCKED;

float32 ChargerM_Timer_F32 = 0.0F;
float32 ChargerM_SetPoint_Curr_F32 = 0.0F;

/* PI Controller Variables */
float32 ChargerM_Error_F32 = 0.0F;
float32 ChargerM_Integrator_F32 = 0.0F;
float32 ChargerM_ProportionalTerm_F32 = 0.0F;
float32 ChargerM_IntegralTerm_F32 = 0.0F;
float32 ChargerM_UnsatVtg_F32 = 0.0F;
float32 ChargerM_SatVtgOut_F32 = 0.0F;
float32 ChargerM_CorrectionSignal_F32 = 0.0F;
float32 ChargerM_IntegratorCorrection_F32 = 0.0F;
float32 ChargerM_UpdatedIntegrator_F32 = 0.0F;

float32 ChargerM_Vbat_F32 = 0.0F;

uint8 ChargerM_LockDutyCycle_U8 = 0U;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ChargerM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ChargerM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    ChargerM_Timer_F32 = 0.0F;
    ChargerM_SetPoint_Curr_F32 = 0.0F;
    ChargerM_Integrator_F32 = 0.0F;
    ChargerM_LockDutyCycle_U8 = 0U;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ChargerM_Proc10ms(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ChargerM_Proc10ms

Description     : This function will be periodically called for 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    float32 MeasuredCurrent_F32 = 0.0F;

    /* Read system state */
    ChargerM_SystemStateSysSig_E = SysStateM_GetCurrentState();

    /* Read inputs */
    ChargerM_ChargerConnectDigIn_U8 = IoHwDio_Read(eIoHwDio_Kl15_InDIN);
    ChargerM_ChargerConnectCan_U8 = CanInp_GetChargerConnectReq();

    /* Evaluate enable condition */
    if ((ChargerM_ChargerConnectDigIn_U8 == IoHwDio_HIGH) ||
        (ChargerM_ChargerConnectCan_U8 == eCanInp_Enable))
    {
        ChargerM_ChargerMStateSysSig_E = eChargerM_Enable;
    }
    else
    {
        ChargerM_ChargerMStateSysSig_E = eChargerM_Disable;
    }

    /*------------------------------------------------------------*/
    /* Charger Lock Control                                       */
    /*------------------------------------------------------------*/

    if ((ChargerM_ChargerMStateSysSig_E == eChargerM_Enable) &&
        (ChargerM_SystemStateSysSig_E == eSysStateM_StopReadyMode))
    {
        ChargerM_ChargerLock = ChargerM_LOCKED;

        /* Peak → Hold logic */
        if (ChargerM_Timer_F32 < ChargerM_PEAK_DURATION)
        {
            ChargerM_SetPoint_Curr_F32 = ChargerM_PEAK_CURRENT;
        }
        else
        {
            ChargerM_SetPoint_Curr_F32 = ChargerM_HOLD_CURRENT;
        }

        ChargerM_Timer_F32 += ChargerM_SAMPLING_TIME;

        /*------------------------------------------------------------*/
        /* Closed Loop Current Control                                */
        /*------------------------------------------------------------*/

        /* Read current feedback */
        MeasuredCurrent_F32 = ChargerCurr_GetFeedback();

        /* Error */
        ChargerM_Error_F32 = ChargerM_SetPoint_Curr_F32 - MeasuredCurrent_F32;

        /* Proportional */
        ChargerM_ProportionalTerm_F32 = ChargerM_KP * ChargerM_Error_F32;

        /* Integral */
        ChargerM_IntegralTerm_F32 = ChargerM_KI * ChargerM_Integrator_F32;

        /* Unsaturated voltage */
        ChargerM_UnsatVtg_F32 = ChargerM_ProportionalTerm_F32 + ChargerM_IntegralTerm_F32;

        /* Saturation */
        ChargerM_SatVtgOut_F32 = MIN(MAX(ChargerM_UnsatVtg_F32, ChargerM_VTG_MIN), ChargerM_VTG_MAX);

        /* Anti-windup back calculation */
        ChargerM_CorrectionSignal_F32 = ChargerM_SatVtgOut_F32 - ChargerM_UnsatVtg_F32;

        ChargerM_IntegratorCorrection_F32 = ChargerM_Error_F32 + ChargerM_BACK_CALC_GAIN * ChargerM_CorrectionSignal_F32;

        ChargerM_UpdatedIntegrator_F32 = ChargerM_Integrator_F32 + ChargerM_SAMPLING_TIME * ChargerM_IntegratorCorrection_F32;

        ChargerM_Integrator_F32 = ChargerM_UpdatedIntegrator_F32;

        /*------------------------------------------------------------*/
        /* Duty Cycle Calculation                                     */
        /*------------------------------------------------------------*/

        ChargerM_Vbat_F32 = DcVolt_GetMcuPhyDcVolt(eDcVoltSens_1);

        if (ChargerM_Vbat_F32 > 6.0F)
        {
            ChargerM_LockDutyCycle_U8 = (ChargerM_SatVtgOut_F32 / ChargerM_Vbat_F32) * 100U;
        }
        else
        {
            ChargerM_LockDutyCycle_U8 = 0U;
        }

        /* Clamp to 80% max */
        if (ChargerM_LockDutyCycle_U8 > 80U)
        {
            ChargerM_LockDutyCycle_U8 = 80U;
        }
    }
    else
    {
        /* Unlock and reset */
        ChargerM_ChargerLock = ChargerM_UNLOCKED;
        ChargerM_Timer_F32 = 0.0F;
        ChargerM_SetPoint_Curr_F32 = 0.0F;
        ChargerM_Integrator_F32 = 0.0F;
        ChargerM_LockDutyCycle_U8 = 0U;
    }
}


float32 ChargerCurr_GetFeedback(void)
{
    // For testing: return a dummy current (0–3A)
    return 0.0f; // No current flowing
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eChargerM_ChargerManagerState ChargerM_GetChargerManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ChargerM_GetChargerManagerState

Description     : This function returns ChargerManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : ChargerM_ChargerMState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return ChargerM_ChargerMStateSysSig_E;
}



















