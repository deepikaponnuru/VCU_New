///*-----------------------------------------------------------------------------------------------------------------------------------------------------------
//
//Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.
//
//Module Name: Charger manager
//
//File Name  : ChargerM.c
//
//Description: This is the Charger manager source file.
//
//Version    : 1.0
//
//Date       : 08/01/2026
//
//-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
//
///*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
//#include "ChargerM_Int.h"
///*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
//eChargerM_ChargerManagerState ChargerM_ChargerMStateSysSig_E      = eChargerM_Disable;
//eSysStateM_SystemState ChargerM_SystemStateSysSig_E               = eSysStateM_WakeUpMode;
//eCanInp_CanState ChargerM_ChargerConnectCan_U8 = eCanInp_Disable;
//uint8 ChargerM_ChargerConnectDigIn_U8 = IoHwDio_LOW;
//uint8 ChargerM_ChargerLock = ChargerM_UNLOCKED;
//float32 ChargerM_Timer_F32 = 0.0F;
//float32 ChargerM_SetPoint_Curr_F32 = 0.0F;
//
//float setpoint_current;
//unsigned long start_time;
//
//// PI Controller variables
//float measured_current;
//float error, integral = 0, control_output;
//float Kp = 0.5f, Ki = 0.1f;
//
//
//
///*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
//void ChargerM_Init(void)
///*---------------------------------------------------------------------------------------------------------------------------------------------------------
//
//Function Name   : ChargerM_Init
//
//Description     : This function initializes the internal variables
//
//In Parameter    : N/A
//
//Out Parameter   : N/A
//
//In-Out Parameter: N/A
//
//Return          : void
//
//-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
//{
//
//}
//
///*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
//void ChargerM_Proc10ms(void)
///*-----------------------------------------------------------------------------------------------------------------------------------------------------------
//
//Function Name   : ChargerM_Proc10ms
//
//Description     : This function will be periodically called for 10ms.
//
//In Parameter    : N/A
//
//Out Parameter   : N/A
//
//In-Out Parameter: N/A
//
//Return          : void
//
//-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
//{
//    /* Get Current System state from SysStateM_GetCurrentState */
//    ChargerM_SystemStateSysSig_E = SysStateM_GetCurrentState();
//
//    ChargerM_ChargerConnectDigIn_U8 = IoHwDio_Read(eIoHwDio_Kl15_InDIN);
//
//    ChargerM_ChargerConnectCan_U8 = CanInp_GetChargerConnectReq();
//
//    if((ChargerM_ChargerConnectDigIn_U8 == IoHwDio_HIGH) || (ChargerM_ChargerConnectCan_U8 == eCanInp_Enable))
//    {
//        ChargerM_ChargerMStateSysSig_E = eChargerM_Enable;
//    }
//    else
//    {
//        ChargerM_ChargerMStateSysSig_E = eChargerM_Disable;
//    }
//
//    /* When Charger Manager State is Enabled and Current System State is Stop Ready Mode */
//    if((ChargerM_ChargerMStateSysSig_E == eChargerM_Enable) && (ChargerM_SystemStateSysSig_E == eSysStateM_StopReadyMode))
//    {
//        /*TO DO : the Charger Lock shall be locked with peak current of  "3A" AND hold current of "1A" */
//        ChargerM_ChargerLock = ChargerM_LOCKED;
//
//        if(ChargerM_Timer_F32 < ChargerM_PEAK_DURATION)
//        {
//            ChargerM_SetPoint_Curr_F32 = ChargerM_PEAK_CURRENT;
//        }
//        else
//        {
//            ChargerM_SetPoint_Curr_F32 = ChargerM_HOLD_CURRENT;
//        }
//
//        ChargerM_Timer_F32 +=  ChargerM_SAMPLING_TIME;
//    }
//    else
//    {
//        /* the Charger Lock shall be Unlocked*/
//        ChargerM_ChargerLock = ChargerM_UNLOCKED;
//        ChargerM_Timer_F32 = 0.0F;
//        ChargerM_SetPoint_Curr_F32 = 0.0F;
//    }
//
//
//}
//
//
//
///*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
//eChargerM_ChargerManagerState ChargerM_GetChargerManagerState(void)
///*---------------------------------------------------------------------------------------------------------------------------------------------------------
//
//Function Name   : ChargerM_GetChargerManagerState
//
//Description     : This function returns ChargerManagerState.
//
//In Parameter    : N/A
//
//Out Parameter   : N/A
//
//In-Out Parameter: N/A
//
//Return          : ChargerM_ChargerMState
//
//-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
//{
//    /* TO DO : Not yet Specified */
//    return ChargerM_ChargerMStateSysSig_E;
//}
//
//
//
