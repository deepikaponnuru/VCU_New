/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Drive manager Internal file

File Name  : DriveM_Int.h

Description: This is the  private header.

Version    : 1.0

Date       : 07/01/2026

----------------------------------------------------------------------------------------------------------------------------------------------------------------*/

#ifndef _DRIVEM_INT_H_
#define _DRIVEM_INT_H_

/*------------------------------------------------------------- Import Module Include Section ------------------------------------------------------------------*/
#include "DriveM_Ext.h"
#include "SysStateM_Ext.h"
#include "ThrottleSensor_Ext.h"
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Global Macros ----------------------------------------------------------------------------------*/
#define DriveM_DISABLE              (0U)
#define DriveM_ENABLE               (1U)
#define DriveM_LOCKED               (0U)
#define DriveM_UNLOCKED             (1U)
#define DriveM_SPEEDTHRESHOLD       (100U)
#define DriveM_BUTTONTHRESHOLD      (150U)
#define DriveM_BUTTONPRESSSAMPLING  (10U)
#define DriveM_TROTTLETHRESHOLD     (10.0F)
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Local Typedefs ---------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/* ------------------------------------------------------------ Global Definitions -----------------------------------------------------------------------------*/

extern eDriveM_DriveManagerState DriveM_DriveMState_E;
extern eSysStateM_SystemState DriveM_SystemState_E;
extern uint8 DriveM_ReverseButtonDigIn_U8;
extern uint8 DriveM_DriveButtonDigIn_U8;
extern uint8 DriveM_BrakePedalStatusDigIn_U8;
extern uint8 DriveM_VehicleLockDigIn_U8;
extern uint8 DriveM_DriveProfileButtonDigIn_U8;
extern float32 DriveM_AvgThrottlePercent_F32;
extern float32 DriveM_MotorSpeedCan_F32;
extern uint8 DriveM_ReverseButtonPressCounter_U8;
extern uint8 DriveM_DriveButtonPressCounter_U8;
extern uint8 DriveM_DriveProfileButtonPressCounter_U8;
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------- Static Function Declarations -------------------------------------------------------------------*/
eDriveM_DriveManagerState DriveM_GetDriveManagerState(void);
/*--------------------------------------------------------------------------------------------------------------------------------------------------------------*/

#endif    /* _DRIVEM_INT_H_ */




