/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Drive manager

File Name  : DriveM.c

Description: This is the Drive manager source file.

Version    : 1.0

Date       : 07/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "DriveM_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

eDriveM_DriveManagerState DriveM_DriveMState_E = eDriveM_Neutral;
eSysStateM_SystemState DriveM_SystemState_E = eSysStateM_WakeUpMode;
uint8 DriveM_ReverseButtonDigIn_U8 = IoHwDio_LOW;
uint8 DriveM_DriveButtonDigIn_U8 = IoHwDio_LOW;
uint8 DriveM_BrakePedalStatusDigIn_U8 = IoHwDio_LOW;
uint8 DriveM_VehicleLockDigIn_U8 = DriveM_LOCKED;
uint8 DriveM_DriveProfileButtonDigIn_U8 = IoHwDio_LOW;
float32 DriveM_AvgThrottlePercent_F32 = 0.0F;
float32 DriveM_MotorSpeedCan_F32 = 0.0F;

uint8 DriveM_ReverseButtonPressCounter_U8 = 0U;
uint8 DriveM_DriveButtonPressCounter_U8 = 0U;
uint8 DriveM_DriveProfileButtonPressCounter_U8 = 0U;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void DriveM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : DriveM_Init

Description     : This function initializes the internal variables

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    DriveM_DriveMState_E = eDriveM_Neutral;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void DriveM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : DriveM_Proc10ms

Description     : This function will be periodically called for 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* Get the current system state from the System State Manager */
    DriveM_SystemState_E = SysStateM_GetCurrentState();

    /* TO DO : Get vehicle lock status from Dio (Yet to implement) */
    DriveM_VehicleLockDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig2DIN);

    /* TO DO : Get drive button status from Dio (Yet to implement) */
    DriveM_DriveButtonDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig3DIN);

    /* TO DO : Get reverse button status from Dio (Yet to implement) */
    DriveM_ReverseButtonDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig4DIN);

    /* TO DO : Get brake pedal status from Dio (Yet to implement) */
    DriveM_BrakePedalStatusDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig5DIN);

    /* TO DO : Get Drive Profile status from Dio (Yet to implement) */
    DriveM_DriveProfileButtonDigIn_U8 = IoHwDio_Read(eIoHwDio_Dig19DIN);

    /* TO DO: fill the function parameters*/
    DriveM_AvgThrottlePercent_F32 = ThrottleSens_GetVAvgPercentThrottleSens1_2(eIoHwAna_Ths1Mon,eIoHwAna_Ths2Mon);

    /* Get the Motor Speed from CanInp */
    DriveM_MotorSpeedCan_F32 = CanInp_GetMcuSpeed();

    /* When the Drive Button is Pressed */
    if(DriveM_DriveButtonDigIn_U8 == IoHwDio_HIGH)
    {
        /* Drive Button Press Counter is incremented */
        DriveM_DriveButtonPressCounter_U8 += DriveM_BUTTONPRESSSAMPLING;
    }
    /* When the Drive Button is released */
    else if(DriveM_DriveButtonDigIn_U8 == IoHwDio_LOW)
    {
        /* Drive Button Press Counter is reset to zero */
        DriveM_DriveButtonPressCounter_U8 = 0U;
    }
    /* When the Reverse Button is Pressed */
    if(DriveM_ReverseButtonDigIn_U8 == IoHwDio_HIGH)
    {
        /* Reverse Button Press Counter is incremented */
        DriveM_ReverseButtonPressCounter_U8 += DriveM_BUTTONPRESSSAMPLING;
    }
    /* When the Reverse Button is released */
    else if(DriveM_ReverseButtonDigIn_U8 == IoHwDio_LOW)
    {
        /* Reverse Button Press Counter is reset to zero */
        DriveM_ReverseButtonPressCounter_U8 = 0U;
    }
    /* When the Drive Profile Button is released */
    if(DriveM_DriveProfileButtonDigIn_U8 == IoHwDio_LOW)
    {
        /* Drive Profile ButtonPressCounter is rest to zero */
        DriveM_DriveProfileButtonPressCounter_U8 = 0U;
    }

    switch(DriveM_DriveMState_E)
    {
        case eDriveM_Neutral :

            /* When the Drive Manager State is Neutral and Reverse button is pressed,
                   brake pedal is applied, throttle is below threshold,
                   vehicle is unlocked and system state is RunMode */
            if((DriveM_ReverseButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD) &&
                    (DriveM_BrakePedalStatusDigIn_U8 == IoHwDio_HIGH) &&
                    (DriveM_AvgThrottlePercent_F32 < DriveM_TROTTLETHRESHOLD) &&
                    (DriveM_VehicleLockDigIn_U8 == IoHwDio_HIGH)&&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState state transit to Reverse state*/
                DriveM_DriveMState_E = eDriveM_Reverse;
            }
            /* When the Drive Manager State is Neutral and Drive button is pressed,
                   brake pedal is applied, throttle is below threshold,
                   vehicle is unlocked and system state is RunMode */
            else if((DriveM_DriveButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD) &&
                    (DriveM_BrakePedalStatusDigIn_U8 == IoHwDio_HIGH) &&
                    (DriveM_AvgThrottlePercent_F32    < DriveM_TROTTLETHRESHOLD) &&
                    (DriveM_VehicleLockDigIn_U8 == IoHwDio_HIGH) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState state transit to Drive_Eco state*/
                DriveM_DriveMState_E = eDriveM_Drive_Eco                                                                                                                                                            ;
            }
            break;

        case eDriveM_Drive_Normal :
            /* When the Drive Profile Button is Pressed */
            if(DriveM_DriveProfileButtonDigIn_U8 == IoHwDio_HIGH)
            {
                /* Drive Profile ButtonPress Counter is incremented*/
                DriveM_DriveProfileButtonPressCounter_U8 += DriveM_BUTTONPRESSSAMPLING;
            }
            /* When DriveProfileButton is pressed for more than threshold */
            if(DriveM_DriveProfileButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD)
            {
                /* The DriveMState state transit to Drive_Sport state*/
                DriveM_DriveMState_E = eDriveM_Drive_Sport;
            }
            /* When the Drive Manager State is Drive and Reverse button is pressed,
                brake pedal is applied, Motor Speed is below threshold
                throttle is below threshold and system state is RunMode */
            else if((DriveM_ReverseButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD) &&
                    (DriveM_BrakePedalStatusDigIn_U8 == IoHwDio_HIGH) &&
                    (DriveM_MotorSpeedCan_F32   < DriveM_SPEEDTHRESHOLD) &&
                    (DriveM_AvgThrottlePercent_F32 < DriveM_TROTTLETHRESHOLD) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState state transit to Reverse state*/
                DriveM_DriveMState_E = eDriveM_Reverse;
            }
            /* When vehicle is Locked and system state is RunMode */
            else if((DriveM_VehicleLockDigIn_U8 == IoHwDio_LOW) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState transit to Neutral state*/
                DriveM_DriveMState_E = eDriveM_Neutral;
            }
            break;

        case eDriveM_Drive_Eco :
            /* When the Drive Profile Button is Pressed */
            if(DriveM_DriveProfileButtonDigIn_U8 == IoHwDio_HIGH)
            {
                /* Drive Profile ButtonPress Counter is incremented*/
                DriveM_DriveProfileButtonPressCounter_U8 += DriveM_BUTTONPRESSSAMPLING;
            }
            /* When DriveProfileButton is pressed for more than threshold */
            if(DriveM_DriveProfileButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD)
            {
                /* The DriveMState state transit to Drive_Normal state*/
                DriveM_DriveMState_E = eDriveM_Drive_Normal;
            }
            /* When the Drive Manager State is Drive and Reverse button is pressed,
                brake pedal is applied, Motor Speed is below threshold
                throttle is below threshold and system state is RunMode */
            else if((DriveM_ReverseButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD) &&
                    (DriveM_BrakePedalStatusDigIn_U8 == IoHwDio_HIGH) &&
                    (DriveM_MotorSpeedCan_F32   < DriveM_SPEEDTHRESHOLD) &&
                    (DriveM_AvgThrottlePercent_F32 < DriveM_TROTTLETHRESHOLD) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState state transit to Reverse state*/
                DriveM_DriveMState_E = eDriveM_Reverse;
            }
            /* When vehicle is Locked and system state is RunMode */
            else if((DriveM_VehicleLockDigIn_U8 == IoHwDio_LOW) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState transit to Neutral state*/
                DriveM_DriveMState_E = eDriveM_Neutral;
            }
            break;

        case eDriveM_Drive_Sport :
            /* When the Drive Profile Button is Pressed */
            if(DriveM_DriveProfileButtonDigIn_U8 == IoHwDio_HIGH)
            {
                /* Drive Profile ButtonPress Counter is incremented*/
                DriveM_DriveProfileButtonPressCounter_U8 += DriveM_BUTTONPRESSSAMPLING;
            }
            /* When DriveProfileButton is pressed for more than threshold */
            if(DriveM_DriveProfileButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD)
            {
                /* The DriveMState state transit to Drive_Eco state*/
                DriveM_DriveMState_E = eDriveM_Drive_Eco;
            }
            /* When the Drive Manager State is Drive and Reverse button is pressed,
                brake pedal is applied, Motor Speed is below threshold
                throttle is below threshold and system state is RunMode */
            else if((DriveM_ReverseButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD) &&
                    (DriveM_BrakePedalStatusDigIn_U8 == IoHwDio_HIGH) &&
                    (DriveM_MotorSpeedCan_F32   < DriveM_SPEEDTHRESHOLD) &&
                    (DriveM_AvgThrottlePercent_F32 < DriveM_TROTTLETHRESHOLD) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState state transit to Reverse state*/
                DriveM_DriveMState_E = eDriveM_Reverse;
            }
            /* When vehicle is Locked and system state is RunMode */
            else if((DriveM_VehicleLockDigIn_U8 == IoHwDio_LOW) &&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState transit to Neutral state*/
                DriveM_DriveMState_E = eDriveM_Neutral;
            }
            break;

        case eDriveM_Reverse :
            /* When the Drive Manager State is Reverse and Drive button is pressed,
               brake pedal is applied, Motor Speed is below threshold
               throttle is below threshold and system state is RunMode */
            if((DriveM_DriveButtonPressCounter_U8 > DriveM_BUTTONTHRESHOLD) &&
                (DriveM_BrakePedalStatusDigIn_U8 == IoHwDio_HIGH) &&
                (DriveM_MotorSpeedCan_F32   < DriveM_SPEEDTHRESHOLD) &&
                (DriveM_AvgThrottlePercent_F32 < DriveM_TROTTLETHRESHOLD) &&
                (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState state transit to Drive Eco state*/
                DriveM_DriveMState_E = eDriveM_Drive_Eco;
            }
            /* When vehicle is Locked and system state is RunMode */
            else if((DriveM_VehicleLockDigIn_U8 == IoHwDio_LOW)&&
                    (DriveM_SystemState_E == eSysStateM_RunMode))
            {
                /* The DriveMState transit to Neutral state*/
                DriveM_DriveMState_E = eDriveM_Neutral;
            }
            break;
    }

}


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eDriveM_DriveManagerState DriveM_GetDriveManagerState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : DriveM_GetDriveManagerState

Description     : This function returns DriveManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : DriveM_DriveMState_E

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return DriveM_DriveMState_E;
}



