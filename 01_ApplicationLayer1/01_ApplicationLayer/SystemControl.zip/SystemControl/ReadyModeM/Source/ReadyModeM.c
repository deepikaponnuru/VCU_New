/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: Ready Mode Manager.

File Name  : ReadyModeM.c

Description: This is the ReadyMode manager source file.

Version    : 1.0

Date       : 05/01/2026

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "ReadyModeM_Int.h"

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eReadyModeM_ReadyModeMState ReadyM_ReadyModeMState_E   = eReadyModeM_NoError;
eSysStateM_SystemState SysStateM_SystemStateIn_E       = eSysStateM_WakeUpMode;
float32 ReadyModeM_TimeInPrechargeActive_F32  = 0.0F;
float32 ReadyModeM_McuVoltage_F32 			  = 0.0F;
float32 ReadyModeM_BmsVoltage_F32 			  = 0.0F;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ReadyModeM_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ReadyModeM_Init

Description     : This function initializes the internal variables 

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void ReadyModeM_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ReadyModeM_Proc10ms

Description     : This function will be periodically called for 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    /* Get current system state from  SysState manager */	
    SysStateM_SystemStateIn_E = SysStateM_GetCurrentState();

    /*TO DO : sensorID's Get current McuVoltage from  DcVolt_GetVMcuPhyDcVolt  */
    ReadyModeM_McuVoltage_F32 = DcVolt_GetMcuPhyDcVolt(eDcVoltSens_1);//TBD

    /*TO DO : sensorID's Get current BmsVoltage from  DcVolt_GetBmsPhyDcVolt  */
    ReadyModeM_BmsVoltage_F32 = DcVolt_GetBmsPhyDcVolt(eDcVoltSens_2);//TBD

    switch(ReadyM_ReadyModeMState_E)
    {
        case eReadyModeM_Inactive :
        /* When the ReadyModeMState is in Inactive state Disable the following Relays*/
        /* TO DO : 1) Disable 12V battery connect Relay
                   2) Disable Pre-charge Path Relay
                   3) disable Dis-charge Path Relay*/
            /* When the ReadyModeMState is in Inactive state and System state is in StartReadyMode*/
            if(SysStateM_SystemStateIn_E == eSysStateM_StartReadyMode)
            {
                /* The ReadyModeMState state transit to PreChargeActive */
                ReadyM_ReadyModeMState_E = eReadyModeM_PreChargeActive;
            }
            break;
			
        case eReadyModeM_PreChargeActive :
        /* When the ReadyModeMState is in PreChargeActive state Enable the following Relays*/
        /* TO DO : 1) Enable 12V battery connect Relay
                   2) Enable pre-charge path Relay*/
            ReadyModeM_TimeInPrechargeActive_F32 = ReadyModeM_TimeInPrechargeActive_F32 + ReadyModeM_SAMPLINGRATE;
            /* When the ReadyModeMState is in PreChargeActive state and TimeInPrechargeActive is greater that 0.5 sec and
               absolute difference is less than or equal to 2 volts*/
            if((ReadyModeM_TimeInPrechargeActive_F32 >= ReadyModeM_TIMER_THRESHOLD) && (fabsf(ReadyModeM_McuVoltage_F32 - ReadyModeM_BmsVoltage_F32) <= ReadyModeM_ABS_DIFFERENCE))
            {
                /* The ReadyModeMState state transit to SystemReady */
                ReadyM_ReadyModeMState_E = eReadyModeM_SystemReady;
            }
            /* When the ReadyModeMState is in PreChargeActive state and TimeInPrechargeActive is greater that 0.5 sec and
               absolute difference is greater than 2 volts*/
            else if((ReadyModeM_TimeInPrechargeActive_F32 >= ReadyModeM_TIMER_THRESHOLD) && (fabsf(ReadyModeM_McuVoltage_F32 - ReadyModeM_BmsVoltage_F32) > ReadyModeM_ABS_DIFFERENCE))
            {
                /* The ReadyModeMState state transit to Error */
                ReadyM_ReadyModeMState_E = eReadyModeM_Error;
            }
            break;
			
        case eReadyModeM_SystemReady:
            /* When the ReadyModeMState is in SystemReady state enable and disable simultaneously these relays*/
            /*TO DO : 1) Enable Discharge Relay 
                      2) After 10ms Disable PreCharge Relay */
            /* When the ReadyModeMState is in SystemReady state and System state is in StopReadyMode*/
            if(SysStateM_SystemStateIn_E == eSysStateM_StopReadyMode)
            {
                /* The ReadyModeMState state transit to SystemDisable */
                ReadyM_ReadyModeMState_E = eReadyModeM_SystemDisable;
            }
            break;
			
        case eReadyModeM_SystemDisable :
            /* When the ReadyModeMState is in SystemDisable state and System state is in ShutDownMode*/
            if(SysStateM_SystemStateIn_E == eSysStateM_ShutDownMode)
            {
                /* The ReadyModeMState state transit to Inactive*/
                ReadyM_ReadyModeMState_E = eReadyModeM_Inactive;
            }
            break;
			
        case eReadyModeM_Error :
             /* When the ReadyModeMState is in Error state and System state is in ShutDownMode*/
            if(SysStateM_SystemStateIn_E == eSysStateM_ShutDownMode)
            {
                /* The ReadyModeMState state transit to Inactive*/
                ReadyM_ReadyModeMState_E = eReadyModeM_Inactive;
            }
            break;
			
        case eReadyModeM_NoError :
            break;
    }

}


/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eReadyModeM_ReadyModeMState ReadyModeM_GetReadyModeMState(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : ReadyModeM_GetReadyModeMState

Description     : This function returns ReadyModeManagerState.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : ReadyM_ReadyModeMState_E

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return ReadyM_ReadyModeMState_E;
}
