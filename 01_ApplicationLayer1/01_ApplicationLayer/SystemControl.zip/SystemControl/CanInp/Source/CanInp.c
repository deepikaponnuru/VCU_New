/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Copyright (c) 2018 iSyriuS engineering Germany Pvt. Ltd. - All Rights Reserved.

Module Name: CAN Input

File Name  : CanInp.c

Description: This is the CAN input source file.

Version    : 1.0

Date       : 11/12/2025

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------- Include Section -----------------------------------------------------------------*/
#include "CanInp_Int.h"
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/

eCanInp_ServiceState CanInp_ServiceStateH2_E = eCanInp_NotRequested;
eCanInp_ServiceState CanInp_ServiceStateFc_E = eCanInp_NotRequested;
eCanInp_ServiceState CanInp_RefuelModeReq_E  = eCanInp_NotRequested;
eCanInp_VehicleLockState CanInp_VehicleLockState_E  = eCanInp_Unlocked;
eCanInp_CanState CanInp_HillHoldReq_E = eCanInp_Disable;
eCanInp_CanState CanInp_ChargerConnect_E = eCanInp_Disable;
float32 CanInp_H2SOCPerc_F32 = 0.0F;
float32 CanInp_McuSpeed_F32 = 0.0F;

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void CanInp_Init(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_Init

Description     : This function initializes the internal variables 

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
void CanInp_Proc10ms(void)
/*-----------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_Proc10ms

Description     : This function is called for every 10ms.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : void 
  			  
-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{	

}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eCanInp_ServiceState CanInp_GetServiceStateH2(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_GetServiceStateH2

Description     : This function returns Service state H2.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eCanInp_ServiceState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_ServiceStateH2_E;
}
/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eCanInp_ServiceState CanInp_GetServiceStateFc(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_GetServiceStateFc

Description     : This function returns Service state Fc.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eCanInp_ServiceState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_ServiceStateFc_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eCanInp_ServiceState CanInp_GetRefuelModeReq(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_GetRefuelModeReq

Description     : This function returns Refuel mode request.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eCanInp_RefuelModeReq

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_RefuelModeReq_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
float CanInp_GetH2SOCPerc(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_GetH2SOCPerc

Description     : This function returns SOC (State of charge ) percentage .

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : float32

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_H2SOCPerc_F32;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eCanInp_VehicleLockState CanInp_GetVehicleLockStateReq(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_GetVehicleLockStateReq

Description     : This function returns vehicle Lock State request.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eCanInp_VehicleLockState

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_VehicleLockState_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eCanInp_CanState CanInp_GetHillHoldReq(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------
Function Name   : CanInp_GetHillHoldReq

Description     : This function returns HillHold State request.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : eCanInp_HillHoldReq
 ---------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_HillHoldReq_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
eCanInp_CanState CanInp_GetChargerConnectReq(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------
Function Name   : CanInp_GetChargerConnectReq

Description     : This function returns ChargerConnect request.

In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : ChargerConnect_E
---------------------------------------------------------------------------------------------------------------------------------------------------------*/

{
    return CanInp_ChargerConnect_E;
}

/*---------------------------------------------------------------------------------------------------------------------------------------------------------*/
float32 CanInp_GetMcuSpeed(void)
/*---------------------------------------------------------------------------------------------------------------------------------------------------------

Function Name   : CanInp_GetMcuSpeed

Description     : This function returns Mcu Speed
In Parameter    : N/A

Out Parameter   : N/A

In-Out Parameter: N/A

Return          : float32

-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
{
    return CanInp_McuSpeed_F32;
}

